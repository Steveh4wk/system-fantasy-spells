fx_version 'cerulean'
games { 'gta5' }

author 'stefanolucianocorp'
description 'Script per maschera on/off con hotkey'

client_script 'client.lua'
