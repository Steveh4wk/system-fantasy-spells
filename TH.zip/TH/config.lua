Config = {}

Config.Text = "[G] Lascialo [H] Colpisci"