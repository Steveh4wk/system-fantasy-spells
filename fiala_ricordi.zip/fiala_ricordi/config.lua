Config = {
    ResourceFolderName = 'fiala_ricordi',
}

-- ox_inventory export
exports('UseVial', function(event, item, inventory)
    if item.name == 'fiala_ricordi' or item.name == 'fiala_ricordi_piena' then
        TriggerEvent('fiala_ricordi:client:UseVial', item, inventory)
    end
end)