var Config = {
    ResourceFolderName: 'fiala_ricordi'
}