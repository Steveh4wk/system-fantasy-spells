let YTPlayer = null;
let isPensatoioMode = false;

function onYouTubeIframeAPIReady() {
}

function onPlayerStateChange(event) {
    if (event.data == YT.PlayerState.ENDED) {
        hideVideo();
    }
}

function onPlayerReady(event) {
}

function PlayVideo(videoID, showCrosshair = false) {
    if (!YTPlayer) {
        allocatePlayer();
    }
    
    // Imposta modalità pensatoio
    isPensatoioMode = showCrosshair;
    
    // Mostra/nasconde elementi in base alla modalità
    document.getElementById('player').style.display = 'block';
    document.getElementById('closeBtn').style.display = 'block';
    
    if (showCrosshair) {
        document.getElementById('crosshair').style.display = 'block';
        document.body.classList.add('pensatoio-mode');
    } else {
        document.getElementById('crosshair').style.display = 'none';
        document.body.classList.remove('pensatoio-mode');
    }
    
    YTPlayer.loadVideoById(videoID);
    
    // Auto-hide dopo 3 minuti per pensatoio, 5 minuti per normale
    const timeout = showCrosshair ? 180000 : 300000;
    setTimeout(() => {
        hideVideo();
    }, timeout);
}

function hideVideo() {
    document.getElementById('player').style.display = 'none';
    document.getElementById('closeBtn').style.display = 'none';
    document.getElementById('crosshair').style.display = 'none';
    document.body.classList.remove('pensatoio-mode');
    
    fetch('https://' + Config.ResourceFolderName + '/HideVideo', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({})
    });
}

function allocatePlayer() {
    YTPlayer = new YT.Player('player', {
        height: '360',
        width: '640',
        videoId: '',
        playerVars: {
            'autoplay': 1,
            'suggestedQuality': 'medium',
            'controls': 1,
            'rel': 0,
            'showinfo': 0
        },
        events: {
            'onStateChange': onPlayerStateChange,
            'onReady': onPlayerReady,
        },
    });
}

document.addEventListener('DOMContentLoaded', function(){
    document.getElementById('closeBtn').addEventListener('click', () => {
        hideVideo();
    });
    
    window.addEventListener('message', function(event) {
        switch(event.data.action) {
            case 'PlayVideo':
                PlayVideo(event.data.videoID, event.data.showCrosshair || false);
                break;
        }
    })
});