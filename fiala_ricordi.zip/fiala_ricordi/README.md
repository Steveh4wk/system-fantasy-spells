# Guida Installazione Fiala Ricordi

Questa guida spiega come installare la risorsa "Fiala Ricordi" nel tuo server FiveM. Segui i passi uno per uno.

## Cosa serve
- Server FiveM con QB-Core e ox_inventory
- Immagini per gli item (file PNG)

## Passi per installare

### 1. Metti la cartella della risorsa
- Copia la cartella `fiala_ricordi` dentro `resources/`
- Nel file `server.cfg`, aggiungi: `ensure fiala_ricordi`

### 2. Immagini degli item
- I file `fiala_ricordi.png` e `fiala_ricordi_piena.png` vanno messi in: `resources/ox_inventory/web/images/`
- Perché: ox_inventory usa questo percorso per le immagini, come impostato in `server.cfg` con `set inventory:imagepath nui://ox_inventory/web/images`

### 3. Item nell'inventario
- Gli item sono già aggiunti in: `resources/ox_inventory/data/items.lua`
- Non serve fare niente, sono già lì con le impostazioni giuste.

### 4. Database
- Esegui il file SQL: `resources/fiala_ricordi/sql/create_table.sql`
- Questo crea la tabella `fiala_ricordi` nel database per salvare i ricordi.

### 5. Test
- Riavvia il server
- Usa `/giveitem` per dare gli item ai giocatori
- Prova a usare le fiale

## Come funziona
- **Fiala Vuota**: Inserisci URL YouTube per riempirla
- **Fiala Piena**: Usa per vedere il video o distruggerla
- **Pensatoio**: Oggetto speciale per vedere ricordi in modalità immersiva (3 minuti)

Se hai problemi, controlla la console per errori.