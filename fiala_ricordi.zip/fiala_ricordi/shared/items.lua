-- Fiala Ricordi Items per ox_inventory
return {
    ['fiala_ricordi'] = {
        label = 'Fiala Vuota',
        weight = 100,
        stack = false,
        close = true,
        description = 'Una fiala vuota per contenere ricordi',
    },
    ['fiala_ricordi_piena'] = {
        label = 'Fiala dei Ricordi',
        weight = 100,
        stack = false,
        close = true,
        description = 'Una fiala contenente un ricordo prezioso',
        metadata = {
            unique_id = {
                label = 'ID Unico',
                description = 'Identificativo unico del ricordo'
            }
        }
    }
}