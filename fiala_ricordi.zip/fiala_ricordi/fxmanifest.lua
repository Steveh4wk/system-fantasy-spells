fx_version "cerulean"
lua54 'yes'
game 'gta5'

description "Fiala Ricordi Resource"
author "Stefano Luciano Corp."

ui_page 'html/index.html'

client_script 'client/client.lua'
server_script 'server/server.lua'
shared_script 'config.lua'

files {
    'html/index.html',
    'html/js/*.js',
}

dependencies {
    'qb-core',
    'oxmysql',
    'ox_inventory',
    'ox_lib'
}

sql_file 'sql/create_table.sql'