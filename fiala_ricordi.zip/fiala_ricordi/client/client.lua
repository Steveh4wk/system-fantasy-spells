-- Callback system
local Callbacks = {}
local CallbackId = 0

function TriggerCallback(name, cb, ...)
    local callbackId = CallbackId + 1
    CallbackId = callbackId
    
    -- Store callback temporarily
    Callbacks[callbackId] = cb
    
    -- Send to server
    TriggerServerEvent('fiala_ricordi:server:TriggerCallback', name, callbackId, ...)
end

-- Handle server callback response
RegisterNetEvent('fiala_ricordi:client:TriggerCallback', function(name, callbackId, ...)
    local cb = Callbacks[callbackId]
    if cb then
        cb(...)
        Callbacks[callbackId] = nil
    end
end)

function extractYouTubeVideoID(url)
    local possibleMatches = {
        '[?&]v=([a-zA-Z0-9_-]+)',
        'youtu.be/([a-zA-Z0-9_-]+)',
        'embed/([a-zA-Z0-9_-]+)',
        'shorts/([a-zA-Z0-9_-]+)',
    }
    local match = nil
    for _, pattern in ipairs(possibleMatches) do
        match = string.match(url, pattern)
        if match then
            return match
        end
    end
end

RegisterNetEvent('fiala_ricordi:client:DestroyVial', function()
    TriggerServerEvent('fiala_ricordi:server:DestroyVial')
end)

RegisterNetEvent('fiala_ricordi:client:UseVial', function(item, inventory)
    print('[FIALA DEBUG] UseVial triggered - Item:', item.name)
    
    if item.name == 'fiala_ricordi' then
        print('[FIALA DEBUG] Fiala vuota rilevata, apro input dialog')
        
        -- SOLUZIONE: Usiamo un delay per bypassare il blocco ox_inventory
        Citizen.SetTimeout(100, function()
            print('[FIALA DEBUG] SOLUZIONE: Trigger dopo delay')
            
            -- Ora ripristiniamo l'input dialog
            local input = exports['ox_lib']:inputDialog('Inserisci URL YouTube', {
                {type = 'input', label = 'YouTube URL', required = true}
            })
            
            if input and input[1] and input[1] ~= "" then
                local url = input[1]
                print('[FIALA DEBUG] SOLUZIONE: URL inserito dall\'utente:', url)
                local videoID = extractYouTubeVideoID(url)
                if videoID then
                    print('[FIALA DEBUG] SOLUZIONE: Video ID estratto:', videoID)
                    print('[FIALA DEBUG] SOLUZIONE: Invio al server...')
                    
                    TriggerServerEvent('fiala_ricordi:server:TestEvent', 'input_test')
                    print('[FIALA DEBUG] SOLUZIONE: TestEvent inviato!')
                    
                    TriggerServerEvent('fiala_ricordi:server:FillVial', url)
                    print('[FIALA DEBUG] SOLUZIONE: FillVial inviato!')
                    
                    exports['ox_lib']:notify({type = 'info', description = 'URL inviato al server!'})
                else
                    print('[FIALA DEBUG] SOLUZIONE: URL YouTube non valido!')
                    exports['ox_lib']:notify({type = 'error', description = 'URL YouTube non valido'})
                end
            else
                print('[FIALA DEBUG] SOLUZIONE: Input annullato o vuoto')
                exports['ox_lib']:notify({type = 'error', description = 'Input annullato'})
            end
        end)
        
        return -- Usciamo subito per evitare il codice problematico
    elseif item.name == 'fiala_ricordi_piena' then
        print('[FIALA DEBUG] Fiala piena rilevata, apro context menu')
        exports['ox_lib']:showContext({
            id = 'destroy_vial',
            title = 'Distruggi Fiala',
            options = {
                {
                    title = 'Visualizza Ricordo',
                    description = 'Guarda il video del ricordo',
                    onSelect = function()
                        print('[FIALA DEBUG] Richiesta visualizzazione ricordo')
                        local item = exports['ox_inventory']:GetItem(cache.playerId, 'fiala_ricordi_piena')
                        if item and item.metadata.unique_id then
                            print('[FIALA DEBUG] Unique_id trovato:', item.metadata.unique_id)
                            TriggerServerEvent('fiala_ricordi:server:GetVialURL', item.metadata.unique_id)
                        else
                            print('[FIALA DEBUG] ERRORE: Nessun unique_id trovato!')
                        end
                    end
                },
                {
                    title = 'Distruggi Ricordo',
                    description = 'Rimuovi il ricordo dalla fiala',
                    onSelect = function()
                        print('[FIALA DEBUG] Richiesta distruzione fiala')
                        TriggerServerEvent('fiala_ricordi:server:DestroyVial')
                    end
                }
            }
        })
    end
end)

-- Pensatoio
local PensatoioProp = nil
local IsUsingPensatoio = false

RegisterCommand('testfiala', function()
    print('[FIALA DEBUG] Comando test eseguito')
    TriggerServerEvent('fiala_ricordi:server:TestEvent', 'comando_test')
    print('[FIALA DEBUG] TestEvent dal comando inviato!')
    exports['ox_lib']:notify({type = 'info', description = 'Test comando inviato!'})
end, false)

RegisterCommand('spawnpensatoio', function()
    local coords = GetEntityCoords(PlayerPedId())
    local prop = CreateObject(GetHashKey('v_res_vase_tall'), coords.x, coords.y, coords.z, true, true, true)
    PlaceObjectOnGroundProperly(prop)
    PensatoioProp = prop
    exports['ox_lib']:notify({type = 'success', description = 'Pensatoio spawnato!'})
end, false)

RegisterNetEvent('QBCore:Client:OnPlayerLoaded', function()
    exports.ox_target:addModel('v_res_vase_tall', {
        {
            name = 'insert_vial',
            event = 'fiala_ricordi:client:InsertVial',
            icon = 'fas fa-vial',
            label = 'Inserisci Fiala nel Pensatoio',
            distance = 2.0
        }
    })
end)

RegisterNetEvent('fiala_ricordi:client:InsertVial', function()
    if IsUsingPensatoio then
        exports['ox_lib']:notify({type = 'error', description = 'Stai già usando il pensatoio'})
        return
    end
    
    TriggerCallback('fiala_ricordi:server:HasFilledVial', function(has, unique_id)
        if has then
            TriggerCallback('fiala_ricordi:server:GetVialURL', function(url)
                if url then
                    local videoID = extractYouTubeVideoID(url)
                    if videoID then
                        -- Attiva modalità pensatoio
                        IsUsingPensatoio = true
                        
                        -- Mostra NUI con video e crosshair
                        SetNuiFocus(true, true)
                        SendNUIMessage({
                            action = 'PlayVideo',
                            videoID = videoID,
                            showCrosshair = true
                        })
                        
                        -- Disabilita movimenti del giocatore
                        FreezeEntityPosition(PlayerPedId(), true)
                        SetEntityVisible(PlayerPedId(), false, 0)
                        
                        exports['ox_lib']:notify({type = 'info', description = 'Stai visualizzando un ricordo nel pensatoio'})
                    end
                end
            end, unique_id)
        else
            exports['ox_lib']:notify({type = 'error', description = 'Non hai una fiala piena'})
        end
    end)
end)

RegisterNetEvent('fiala_ricordi:client:PlayVideo', function(url)
    -- Questo evento ora viene usato solo per il context menu, non per il pensatoio
    local videoID = extractYouTubeVideoID(url)
    if videoID then
        SetNuiFocus(true, false)
        SendNUIMessage({
            action = 'PlayVideo',
            videoID = videoID,
            showCrosshair = false
        })
    end
end)

RegisterNUICallback('HideVideo', function(data, cb)
    SetNuiFocus(false, false)
    
    -- Se stava usando il pensatoio, ripristina il giocatore
    if IsUsingPensatoio then
        IsUsingPensatoio = false
        FreezeEntityPosition(PlayerPedId(), false)
        SetEntityVisible(PlayerPedId(), true, 0)
        exports['ox_lib']:notify({type = 'info', description = 'Ricordo terminato'})
    end
    
    cb('ok')
end)