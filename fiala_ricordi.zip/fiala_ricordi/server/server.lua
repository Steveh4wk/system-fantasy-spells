-- QB Core initialization
local QBCore = exports['qb-core']:GetCoreObject()

local MySQL = exports.oxmysql

-- Registra gli item in ox_inventory
local items = {
    ['fiala_ricordi'] = {
        label = 'Fiala Vuota',
        weight = 100,
        stack = false,
        close = true,
        description = 'Una fiala vuota per contenere ricordi',
        client = {
            event = 'fiala_ricordi:client:UseVial'
        }
    },
    ['fiala_ricordi_piena'] = {
        label = 'Fiala dei Ricordi',
        weight = 100,
        stack = false,
        close = true,
        description = 'Una fiala contenente un ricordo prezioso',
        client = {
            event = 'fiala_ricordi:client:UseVial'
        },
        metadata = {
            unique_id = {
                label = 'ID Unico',
                description = 'Identificativo unico del ricordo'
            }
        }
    }
}
exports.ox_inventory:Items(items)
print('[FIALA DEBUG] Items registrati in ox_inventory')

-- QBX callback system
local Callbacks = {}
local CallbackId = 0

function RegisterCallback(name, cb)
    Callbacks[name] = cb
end

-- Trigger client callback
function TriggerClientCallback(name, source, cb, ...)
    local callbackId = CallbackId + 1
    CallbackId = callbackId
    
    -- Store callback temporarily
    local tempCallbacks = _G.TempCallbacks or {}
    _G.TempCallbacks = tempCallbacks
    tempCallbacks[callbackId] = cb
    
    -- Send to client
    TriggerClientEvent('fiala_ricordi:client:TriggerCallback', source, name, callbackId, ...)
end

-- Handle client callback response
RegisterNetEvent('fiala_ricordi:server:CallbackResponse', function(callbackId, ...)
    local tempCallbacks = _G.TempCallbacks or {}
    local cb = tempCallbacks[callbackId]
    if cb then
        cb(...)
        tempCallbacks[callbackId] = nil
    end
end)

-- Debug: Verifica che l'evento venga registrato
print('[FIALA DEBUG] SERVER: Registrando evento FillVial...')

-- Test event per verificare comunicazione
RegisterNetEvent('fiala_ricordi:server:TestEvent', function(message)
    local src = source
    print('[FIALA DEBUG] SERVER: TestEvent ricevuto da source:', src, 'message:', message)
    TriggerClientEvent('ox_lib:notify', src, {type = 'success', description = 'TestEvent ricevuto!'})
end)

print('[FIALA DEBUG] SERVER: TestEvent registrato!')

RegisterNetEvent('fiala_ricordi:server:FillVial', function(url)
    local src = source
    if not src or not url then return end
    
    print('[FIALA DEBUG] SERVER: Ricevuta richiesta FillVial da source:', src)
    print('[FIALA DEBUG] SERVER: URL ricevuto:', url)
    
    -- Notifica immediata al client
    TriggerClientEvent('ox_lib:notify', src, {type = 'info', description = 'Server sta processando la richiesta...'})
    
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then 
        print('[FIALA DEBUG] SERVER: Player non trovato per source:', src)
        TriggerClientEvent('ox_lib:notify', src, {type = 'error', description = 'Player non trovato'})
        return 
    end
    
    print('[FIALA DEBUG] SERVER: Player trovato:', Player.PlayerData.citizenid)
    
    local hasItem = exports['ox_inventory']:GetItem(src, 'fiala_ricordi')
    if not hasItem or hasItem.count < 1 then
        print('[FIALA DEBUG] SERVER: Nessuna fiala vuota trovata')
        TriggerClientEvent('ox_lib:notify', src, {type = 'error', description = 'Non hai una fiala vuota'})
        return
    end
    
    print('[FIALA DEBUG] SERVER: Check fiala vuota - Has:', hasItem ~= nil, 'Count:', hasItem and hasItem.count or 0)
    
    local unique_id = 'fiala_' .. tostring(os.time()) .. '_' .. tostring(math.random(1000,9999))
    print('[FIALA DEBUG] SERVER: Generato unique_id:', unique_id)
    
    -- Inserimento sicuro nel database
    MySQL.insert('INSERT INTO fiala_ricordi (unique_id, citizenid, youtube_url) VALUES (?, ?, ?)', {unique_id, Player.PlayerData.citizenid, url}, function(insertId)
        if insertId then
            print('[FIALA DEBUG] SERVER: MySQL insert result - insertId:', insertId)

            -- Rimuovi fiala vuota
            local removeSuccess = exports['ox_inventory']:RemoveItem(src, 'fiala_ricordi', 1)
            print('[FIALA DEBUG] SERVER: RemoveItem result:', removeSuccess)

            if removeSuccess then
                -- Aggiungi fiala piena
                local addSuccess = exports['ox_inventory']:AddItem(src, 'fiala_ricordi_piena', 1, {unique_id = unique_id})
                print('[FIALA DEBUG] SERVER: AddItem result:', addSuccess)

                if addSuccess then
                    print('[FIALA DEBUG] SERVER: Fiala creata con successo! ID:', unique_id)
                    TriggerClientEvent('ox_lib:notify', src, {type = 'success', description = 'Fiala riempita con successo!'})
                else
                    print('[FIALA DEBUG] SERVER: ERRORE: AddItem fallito, restituisco fiala vuota')
                    -- Se AddItem fallisce, prova a restituire la fiala vuota
                    exports['ox_inventory']:AddItem(src, 'fiala_ricordi', 1)
                    TriggerClientEvent('ox_lib:notify', src, {type = 'error', description = 'Errore nell\'aggiungere la fiala piena'})
                end
            else
                print('[FIALA DEBUG] SERVER: ERRORE: RemoveItem fallito')
                TriggerClientEvent('ox_lib:notify', src, {type = 'error', description = 'Errore nel rimuovere la fiala vuota'})
            end
        else
            print('[FIALA DEBUG] SERVER: ERRORE: Inserimento database fallito!')
            TriggerClientEvent('ox_lib:notify', src, {type = 'error', description = 'Errore nel riempire la fiala'})
        end
    end)
end)

print('[FIALA DEBUG] SERVER: Evento FillVial registrato correttamente!')

RegisterNetEvent('fiala_ricordi:server:DestroyVial', function()
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end
    local item = exports['ox_inventory']:GetItem(src, 'fiala_ricordi_piena')
    if not item or item.count < 1 then
        TriggerClientEvent('ox_lib:notify', src, {type = 'error', description = 'Non hai una fiala piena'})
        return
    end
    local unique_id = item.metadata.unique_id
    if unique_id then
        MySQL.update('DELETE FROM fiala_ricordi WHERE unique_id = ?', {unique_id}, function(affectedRows)
            exports['ox_inventory']:RemoveItem(src, 'fiala_ricordi_piena', 1)
            TriggerClientEvent('ox_lib:notify', src, {type = 'success', description = 'Fiala distrutta'})
        end)
    end
end)

-- QBX usa RegisterCallback invece di lib.callback
RegisterCallback('fiala_ricordi:server:HasFilledVial', function(source, cb)
    local item = exports['ox_inventory']:GetItem(source, 'fiala_ricordi_piena')
    if item and item.count > 0 then
        cb(true, item.metadata.unique_id)
    else
        cb(false)
    end
end)

RegisterCallback('fiala_ricordi:server:GetVialURL', function(source, cb, unique_id)
    MySQL.query('SELECT youtube_url FROM fiala_ricordi WHERE unique_id = ?', {unique_id}, function(result)
        if result and result[1] then
            cb(result[1].youtube_url)
        else
            cb(false)
        end
    end)
end)

-- Nuovo callback per ottenere URL direttamente
RegisterNetEvent('fiala_ricordi:server:GetVialURL', function(unique_id)
    local src = source
    MySQL.query('SELECT youtube_url FROM fiala_ricordi WHERE unique_id = ?', {unique_id}, function(result)
        if result and result[1] then
            TriggerClientEvent('fiala_ricordi:client:PlayVideo', src, result[1].youtube_url)
        else
            TriggerClientEvent('ox_lib:notify', src, {type = 'error', description = 'URL non trovato'})
        end
    end)
end)

-- Export callback system for other resources
exports('TriggerCallback', TriggerClientCallback)
exports('RegisterCallback', RegisterCallback)
